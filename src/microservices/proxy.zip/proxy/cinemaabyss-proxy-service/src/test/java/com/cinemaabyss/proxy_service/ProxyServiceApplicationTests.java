package com.cinemaabyss.proxy_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProxyServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
