package com.cinemaabyss.events_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
