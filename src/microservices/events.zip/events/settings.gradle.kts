rootProject.name = "events-service"
